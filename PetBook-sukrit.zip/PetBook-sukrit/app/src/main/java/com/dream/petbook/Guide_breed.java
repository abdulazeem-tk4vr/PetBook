package com.dream.petbook;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.LinearLayout;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import de.hdodenhof.circleimageview.CircleImageView;

public class Guide_breed extends Fragment {

    private StorageReference storageRef;
    CircleImageView pic;
    LinearLayout l1,l2;
    ImageButton nav;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.activity_guide_breed, container, false);
        pic=v.findViewById(R.id.pic);
        // String uid=FirebaseAuth.getInstance().getCurrentUser().getUid();
        String uid="JMDBomiSiIc7MTQxGq7hhbvGSkD3";
        storageRef = FirebaseStorage.getInstance().getReference("profile/"+uid);
        Task<Uri> uri= storageRef.getDownloadUrl().addOnCompleteListener(new OnCompleteListener<Uri>() {
            @Override
            public void onComplete(@NonNull Task<Uri> task) {
                Uri ur=task.getResult();
                Glide.with(Guide_breed.this).load(ur).into(pic);
            }
        });
        l1=v.findViewById(R.id.lab);
        l2=v.findViewById(R.id.germ);
        nav = v.findViewById(R.id.nav);

        nav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ((DashboardActivity) getActivity()).minimiseFrameLayout();
            }
        });
        l1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ((DashboardActivity)getActivity()).lab();
            }
        });
        l2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ((DashboardActivity)getActivity()).germ();
            }
        });
        return v;
    }
}