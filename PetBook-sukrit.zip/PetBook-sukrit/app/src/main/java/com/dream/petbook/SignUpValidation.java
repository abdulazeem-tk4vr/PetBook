package com.dream.petbook;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;

public class SignUpValidation {
    private Context context;

    public SignUpValidation(Context context) {
        this.context = context;
    }

    public boolean isEditTextFilled(EditText editText, String message) {
        if (editText.getText().toString().trim().isEmpty()) {
            editText.setError(message);
            hideKeyboardFrom(editText);
            return false;
        }
        return true;
    }

    public boolean isPhoneLength10(EditText editText, String message) {
        if (editText.getText().toString().trim().length() != 13) {
            editText.setError(message);
            hideKeyboardFrom(editText);
            return false;
        }
        return true;
    }

    public boolean isPhoneNumeric(EditText editText, String message) {
        try {
            double phone_no = Double.parseDouble(editText.getText().toString().trim());
            return true;
        } catch (NumberFormatException no) {
            editText.setError(message);
            hideKeyboardFrom(editText);
            return false;
        }
    }

    private void hideKeyboardFrom(View view) {
        InputMethodManager imm = (InputMethodManager) context.getSystemService(Activity.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(view.getWindowToken(), WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
    }
}