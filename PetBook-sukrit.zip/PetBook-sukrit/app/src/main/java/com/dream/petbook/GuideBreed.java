package com.dream.petbook;


import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;

public class GuideBreed extends AppCompatActivity implements View.OnClickListener{


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle extras = getIntent().getExtras();
        String t = (String) extras.get("t");
        if(t.equalsIgnoreCase("lab"))
            setContentView(R.layout.guide_breed_info1);
        else
            setContentView(R.layout.guide_breed_info2);

        TextView showhealth = findViewById(R.id.show_health);

        TextView showgrooming = findViewById(R.id.show_grooming);

        TextView showexcercise = findViewById(R.id.show_excercise);

        TextView showtraining = findViewById(R.id.show_training);

        TextView shownutrition = findViewById(R.id.show_nutrition);
        CardView cardview = findViewById(R.id.cardview_expandable);
        cardview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openGuideBreed();
            }
        });




        showhealth.setOnClickListener(this);
        showgrooming.setOnClickListener(this);
        showexcercise.setOnClickListener(this);
        showtraining.setOnClickListener(this);
        shownutrition.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.show_health: {
                View expandablehealth = findViewById(R.id.expandable_health);
                expandablehealth.setVisibility((expandablehealth.getVisibility() == View.VISIBLE)
                        ? View.GONE : View.VISIBLE);
            }

            case R.id.show_grooming: {
                View expandablegrooming = findViewById(R.id.expandable_grooming);
                expandablegrooming.setVisibility((expandablegrooming.getVisibility() == View.VISIBLE)
                        ? View.GONE : View.VISIBLE);
            }

            case R.id.show_excercise: {
                View expandableexcercise = findViewById(R.id.expandable_excercise);
                expandableexcercise.setVisibility((expandableexcercise.getVisibility() == View.VISIBLE)
                        ? View.GONE : View.VISIBLE);
            }

            case R.id.show_training: {
                View expandabletraining = findViewById(R.id.expandable_training);
                expandabletraining.setVisibility((expandabletraining.getVisibility() == View.VISIBLE)
                        ? View.GONE : View.VISIBLE);
            }

            case R.id.show_nutrition: {
                View expandablenutrition = findViewById(R.id.expandable_nutrition);
                expandablenutrition.setVisibility((expandablenutrition.getVisibility() == View.VISIBLE)
                        ? View.GONE : View.VISIBLE);
            }


        }
    }

    public void openGuideBreed(){
        Intent intent = new Intent(this, Guide_breed.class);
        startActivity(intent);
    }

}



