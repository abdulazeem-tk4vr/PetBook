package com.dream.petbook;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.card.MaterialCardView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

public class BuyListFragment extends Fragment {

    ImageButton nav;
    FirebaseFirestore db;
    TextView heading;
    LinearLayout linearLayoutScroll;
    StorageReference storageRef;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_buy_list, container, false);

        db = FirebaseFirestore.getInstance();

        nav = v.findViewById(R.id.nav);
        heading = v.findViewById(R.id.heading);
        linearLayoutScroll = v.findViewById(R.id.pet_list);

        loadPets();

        switch(((DashboardActivity) getActivity()).selected) {
            case "adopt":
                heading.setText("Adopt Pets");
                heading.setTextColor(Color.parseColor("#6EC6CA"));
                break;
            case "found":
                heading.setText("Found Pets");
                heading.setTextColor(Color.parseColor("#950F47"));
                break;
            case "lost":
                heading.setText("Lost Pets");
                heading.setTextColor(Color.parseColor("#EB564E"));
                break;
            case "buy":
                heading.setText("Buy Pets");
                heading.setTextColor(Color.parseColor("#569051"));
                break;
        }

        nav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ((DashboardActivity) getActivity()).minimiseFrameLayout();
            }
        });

        return v;
    }

    public void loadPets() {
        linearLayoutScroll.removeAllViews();
        db.collection("posts").whereEqualTo("type", ((DashboardActivity) getActivity()).selected).get().addOnCompleteListener(task -> {
            if(task.isSuccessful()) {
                QuerySnapshot docs = task.getResult();

                for(int i = 0;i < docs.size(); ) {
                    DocumentSnapshot doc1 = null, doc2 = null;
                    doc1 = docs.getDocuments().get(i);
                    i++;
                    if(i < docs.size()) {
                        doc2 = docs.getDocuments().get(i);
                        i++;
                    }
                    LayoutInflater layoutInflater = LayoutInflater.from(getContext());
                    LinearLayout linearLayout = (LinearLayout) layoutInflater.inflate(R.layout.sale_pet_card, null, false);
                    MaterialCardView card1 = linearLayout.findViewById(R.id.pet1);
                    MaterialCardView card2 = linearLayout.findViewById(R.id.pet2);

                    TextView petName1 = card1.findViewById(R.id.pet_name);
                    TextView petDetails1 = card1.findViewById(R.id.pet_details);
                    TextView petAge1 = card1.findViewById(R.id.pet_age);
                    TextView location1 = card1.findViewById(R.id.location);
                    ImageView pic1 = card1.findViewById(R.id.pic1);

                    petName1.setText((String) doc1.get("name"));
                    petDetails1.setText((String) doc1.get("desc"));
                    petAge1.setText((String) doc1.get("age") + " Years");

                    storageRef = FirebaseStorage.getInstance().getReference("posts/" + (String) doc1.get("type") +(String) doc1.getId() + "0");

                    storageRef.getDownloadUrl().addOnCompleteListener(new OnCompleteListener<Uri>() {
                        @Override
                        public void onComplete(@NonNull Task<Uri> task) {
                            if(task.isSuccessful()) Glide.with(getContext()).load(task.getResult()).into(pic1);
                        }
                    });


                    //location1.setText((String) doc1.get(""));

                    DocumentSnapshot finalDoc = doc1;
                    card1.setOnClickListener(v -> {
                        Intent intent = new Intent(getContext(), PetDetailActivity.class);
                        intent.putExtra("id", finalDoc.getId());
                        startActivity(intent);
                    });

                    if(doc2 != null) {
                        TextView petName2 = card2.findViewById(R.id.pet_name2);
                        TextView petDetails2 = card2.findViewById(R.id.pet_details2);
                        TextView petAge2 = card2.findViewById(R.id.pet_age2);
                        TextView location2 = card2.findViewById(R.id.location2);
                        ImageView pic2 = card2.findViewById(R.id.pic2);

                        storageRef = FirebaseStorage.getInstance().getReference("posts/" + (String) doc2.get("type") +(String) doc2.getId() + "0");

                        storageRef.getDownloadUrl().addOnCompleteListener(new OnCompleteListener<Uri>() {
                            @Override
                            public void onComplete(@NonNull Task<Uri> task) {
                                if(task.isSuccessful()) Glide.with(getContext()).load(task.getResult()).into(pic2);
                            }
                        });

                        petName2.setText((String) doc2.get("name"));
                        petDetails2.setText((String) doc2.get("desc"));
                        petAge2.setText((String) doc2.get("age") + " Years");
                        //location2.setText((String) doc2.get(""));

                        DocumentSnapshot finalDoc1 = doc2;
                        card2.setOnClickListener(v2 -> {
                            Intent intent = new Intent(getContext(), PetDetailActivity.class);
                            intent.putExtra("id", finalDoc1.getId());
                            startActivity(intent);
                        });
                    } else {
                        card2.setVisibility(View.INVISIBLE);
                    }

                    linearLayoutScroll.addView(linearLayout);
                }
            }
        }).addOnFailureListener(e -> Toast.makeText(getContext(), "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }
}