package com.dream.petbook;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.EditText;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.AppCompatButton;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;

import de.hdodenhof.circleimageview.CircleImageView;

public class SignUp extends AppCompatActivity {

    private CircleImageView profile_image;
    private EditText signup_name;
    private EditText signup_city;
    private EditText signup_pin;
    private EditText signup_phone;
    private SignUpValidation valid;
    private AppCompatButton send_otp;
    private Uri uri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);
        setViews();
        valid = new SignUpValidation(SignUp.this);
    }

    @Override
    protected void onStart() {
        super.onStart();

        send_otp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!valid.isEditTextFilled(signup_name, "Enter name") || !valid.isEditTextFilled(signup_city, "Enter city") ||
                        !valid.isEditTextFilled(signup_pin, "Enter pincode") || !valid.isEditTextFilled(signup_phone, "Enter Phone number") || !valid.isPhoneLength10(signup_phone, "Enter 10 digit phone number with country code"))
                    return;
                String tempuri;
                try {
                    tempuri = uri.toString();
                } catch (Exception e) {
                    tempuri = "";
                }
                User user = new User(signup_name.getText().toString().trim(), signup_city.getText().toString().trim(),
                        signup_pin.getText().toString().trim(), signup_phone.getText().toString().trim(), tempuri);
                Intent intent = new Intent(getApplicationContext(), OtpVerify.class);
                intent.putExtra("USER", (Parcelable) user);
                startActivity(intent);
            }
        });
        profile_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getImage.launch("image/*");
            }
        });
    }

    ActivityResultLauncher<String> getImage = registerForActivityResult(new ActivityResultContracts.GetContent(),
            new ActivityResultCallback<Uri>() {
                @Override
                public void onActivityResult(Uri uri1) {
                    // Handle the returned Uri
                    uri = uri1;
                    profile_image.setImageURI(uri1);
                }
            });

    protected void setViews() {
        profile_image = (CircleImageView) findViewById(R.id.profile_image);

        signup_name = (EditText) findViewById(R.id.signup_name);
        signup_city = (EditText) findViewById(R.id.signup_city);
        signup_pin = (EditText) findViewById(R.id.signup_pin);
        signup_phone = (EditText) findViewById(R.id.signup_phone);
        send_otp = (AppCompatButton) findViewById(R.id.send_otp);

        Glide.with(this).load(FirebaseAuth.getInstance().getCurrentUser().getPhotoUrl()).into(profile_image);
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        outState.putString("name", signup_name.getText().toString().trim());
        outState.putString("city", signup_city.getText().toString().trim());
        outState.putString("pin", signup_pin.getText().toString().trim());
        outState.putString("phone", signup_phone.getText().toString().trim());

        // call superclass to save any view hierarchy
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onRestoreInstanceState(Bundle savedInstanceState) {
        signup_name.setText(savedInstanceState.getString("name"));
        signup_city.setText(savedInstanceState.getString("city"));
        signup_pin.setText(savedInstanceState.getString("pin"));
        signup_phone.setText(savedInstanceState.getString("phone"));
    }
}