package com.dream.petbook;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

import me.zhanghai.android.materialratingbar.MaterialRatingBar;

public class FeedbackActivity extends AppCompatActivity {

    EditText feedback;
    MaterialRatingBar rating;
    Button send;
    FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);

        feedback = findViewById(R.id.feed);
        rating = findViewById(R.id.rating);
        send = findViewById(R.id.send);
        db = FirebaseFirestore.getInstance();

        send.setOnClickListener(v -> {
            Map<String, Object> data = new HashMap<>();
            data.put("text", feedback.getText().toString());
            data.put("rating", rating.getRating());
            data.put("user", FirebaseAuth.getInstance().getCurrentUser().getUid());

            db.collection("feedback").add(data).addOnCompleteListener(new OnCompleteListener<DocumentReference>() {
                @Override
                public void onComplete(@NonNull Task<DocumentReference> task) {
                    Toast.makeText(FeedbackActivity.this, "Feedback Sent!", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(FeedbackActivity.this, DashboardActivity.class));
                }
            });
        });


    }
}