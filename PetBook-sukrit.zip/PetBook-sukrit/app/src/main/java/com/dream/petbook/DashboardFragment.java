package com.dream.petbook;

import android.content.Intent;
import android.graphics.Color;
import android.media.Image;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.getbase.floatingactionbutton.FloatingActionButton;
import com.getbase.floatingactionbutton.FloatingActionsMenu;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import de.hdodenhof.circleimageview.CircleImageView;

public class DashboardFragment extends Fragment {

    GridView grid;
    TextView userName;
    CircleImageView pic;
    ImageButton nav;
    FrameLayout frameLayout;
    private StorageReference storageRef;
    FirebaseFirestore db;
    FloatingActionsMenu addpost;
    FloatingActionButton adoptpost,lostpost,foundpost,buypost;
    public static Fragment fragment;
    LinearLayout boostedPosts;

    int icons[] =
            {
                    R.drawable.a,
                    R.drawable.b,
                    R.drawable.c,
                    R.drawable.d,
                    R.drawable.e,
                    R.drawable.f
            };
    String name[] = {"Adopt", "Found", "Lost", "Buy", "PetCare", "Guide"};

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_dashboard, container, false);

        grid = (GridView) v.findViewById(R.id.datagrid);
        userName = v.findViewById(R.id.user_name);
        pic = v.findViewById(R.id.pic);
        nav = v.findViewById(R.id.nav);
        boostedPosts = v.findViewById(R.id.boosted_posts);
        db = FirebaseFirestore.getInstance();

        nav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ((DashboardActivity) getActivity()).minimiseFrameLayout();
            }
        });

        addpost = v.findViewById(R.id.addpost);
        adoptpost= v.findViewById(R.id.adoptpost);
        lostpost= v.findViewById(R.id.lostpost);
        buypost= v.findViewById(R.id.buypost);
        foundpost= v.findViewById(R.id.foundpost) ;

        pic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ((DashboardActivity) getActivity()).loadFragment(ProfileFragment.class);
                ((DashboardActivity) getActivity()).dimTextColors(((DashboardActivity) getActivity()).profile);
            }
        });

        adoptpost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addpost.collapse();
                ((DashboardActivity)getActivity()).addAdopt();
            }
        });

        foundpost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addpost.collapse();
                ((DashboardActivity)getActivity()).addFound();
            }
        });
        lostpost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addpost.collapse();
                ((DashboardActivity)getActivity()).addLost();
            }
        });
        buypost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addpost.collapse();
                ((DashboardActivity)getActivity()).addBuy();
            }
        });

        String uid=FirebaseAuth.getInstance().getCurrentUser().getUid();
        loadBoostedPosts();

        storageRef = FirebaseStorage.getInstance().getReference("profile/"+uid);
        Task<Uri> uri= storageRef.getDownloadUrl().addOnCompleteListener(new OnCompleteListener<Uri>() {
            @Override
            public void onComplete(@NonNull Task<Uri> task) {
                if(task.isSuccessful()) {
                    Uri ur=task.getResult();
                    Glide.with(getContext()).load(ur).into(pic);
                }
            }
        });

        db= FirebaseFirestore.getInstance();

        DocumentReference docRef = db.collection("users").document(uid);
        docRef.get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                User user = documentSnapshot.toObject(User.class);
                userName.setText(user.getName());
            }
        });

        DashboardAdapter obj = new DashboardAdapter(getContext(), name, icons);
        grid.setAdapter(obj);

        return v;
    }

    public void loadBoostedPosts() {
        boostedPosts.removeAllViews();
        db.collection("posts").whereEqualTo("boost", "y").get().addOnCompleteListener(task -> {
            QuerySnapshot docs = task.getResult();

            for(DocumentSnapshot doc: docs) {
                LayoutInflater layoutInflater = LayoutInflater.from(getContext());
                CardView cardView = (CardView) layoutInflater.inflate(R.layout.cardview, null, false);
                TextView petName = cardView.findViewById(R.id.petname);
                TextView petBreed = cardView.findViewById(R.id.petbreed);
                TextView type = cardView.findViewById(R.id.status);
                ImageView pic = cardView.findViewById(R.id.petimage);
                TextView location = cardView.findViewById(R.id.location);

                petName.setText((String) doc.get("name"));
                petBreed.setText((String) doc.get("breed"));
                type.setText(doc.get("type").toString().toUpperCase());
                switch(doc.get("type").toString().toLowerCase()) {
                    case "adopt":
                        type.setTextColor(Color.parseColor("#6EC6CA"));
                        break;
                    case "found":
                        type.setTextColor(Color.parseColor("#950F47"));
                        break;
                    case "lost":
                        type.setTextColor(Color.parseColor("#EB564E"));
                        break;
                    case "buy":
                        type.setTextColor(Color.parseColor("#569051"));
                        break;
                }

                storageRef = FirebaseStorage.getInstance().getReference("posts/"+doc.get("type").toString().toLowerCase()+doc.getId()+"0");
                storageRef.getDownloadUrl().addOnCompleteListener(task1 -> {
                    if(task1.isSuccessful()) Glide.with(getContext()).load(task1.getResult()).into(pic);
                });

                //location.setText((String) doc.get("location"));
                cardView.setOnClickListener(v -> {
                    Intent intent = new Intent(getContext(), PetDetailActivity.class);
                    intent.putExtra("id", doc.getId());
                    startActivity(intent);
                });
                boostedPosts.addView(cardView);
            }
        });
    }
}