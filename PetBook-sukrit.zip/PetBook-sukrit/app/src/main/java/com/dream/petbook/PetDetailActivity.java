package com.dream.petbook;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.widget.NestedScrollView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.smarteist.autoimageslider.IndicatorView.animation.type.IndicatorAnimationType;
import com.smarteist.autoimageslider.SliderAnimations;
import com.smarteist.autoimageslider.SliderView;

import java.util.ArrayList;
import java.util.List;

public class PetDetailActivity extends AppCompatActivity implements OnMapReadyCallback {

    String postId;
    FirebaseFirestore db;
    private TextView petName, petDesc, petPrice, petHeight, petColor, petWeight, petLocation;
    Button call;
    SliderView sliderView;
    StorageReference storageRef;
    NestedScrollView nestedScrollView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pet_detail);

        db = FirebaseFirestore.getInstance();
        petName = findViewById(R.id.pet_name);
        petDesc = findViewById(R.id.desc);
        petHeight = findViewById(R.id.height);
        petColor = findViewById(R.id.color);
        petWeight = findViewById(R.id.weight);
        call = findViewById(R.id.call);
        sliderView = findViewById(R.id.imageSlider);
        petLocation = findViewById(R.id.location);
        nestedScrollView = findViewById(R.id.nested);

        postId = getIntent().getStringExtra("id");

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        ((WorkaroundMapFragment) getSupportFragmentManager().findFragmentById(R.id.map)).setListener(() -> nestedScrollView.requestDisallowInterceptTouchEvent(true));

        loadAndSetPetDetails();
    }

    public void loadImages(String type) {
        List<String> list = new ArrayList<>();
        storageRef = FirebaseStorage.getInstance().getReference("posts/" + type + postId + "0");
        storageRef.getDownloadUrl().addOnCompleteListener(new OnCompleteListener<Uri>() {
            @Override
            public void onComplete(@NonNull Task<Uri> task) {
                if(task.isSuccessful()) list.add(task.getResult().toString());
                storageRef = FirebaseStorage.getInstance().getReference("posts/" + type + postId + "1");
                storageRef.getDownloadUrl().addOnCompleteListener(new OnCompleteListener<Uri>() {
                    @Override
                    public void onComplete(@NonNull Task<Uri> task1) {
                        if(task1.isSuccessful()) list.add(task1.getResult().toString());
                        storageRef = FirebaseStorage.getInstance().getReference("posts/" + type + postId + "2");
                        storageRef.getDownloadUrl().addOnCompleteListener(new OnCompleteListener<Uri>() {
                            @Override
                            public void onComplete(@NonNull Task<Uri> task3) {
                                if(task3.isSuccessful()) list.add(task3.getResult().toString());
                                sliderView.setSliderAdapter(new SliderAdapter(PetDetailActivity.this, list));
                                sliderView.setIndicatorAnimation(IndicatorAnimationType.WORM);
                                sliderView.setSliderTransformAnimation(SliderAnimations.SIMPLETRANSFORMATION);
                                sliderView.startAutoCycle();
                            }
                        });
                    }
                });

            }
        });
    }

    public void loadAndSetPetDetails() {
        db.collection("posts").document(postId).get().addOnCompleteListener(task -> {
            petName.setText((String) task.getResult().get("name"));
            petDesc.setText((String) task.getResult().get("desc"));
            //petPrice.setText((String) task.getResult().get("price"));
            petHeight.setText((String) task.getResult().get("height"));
            petColor.setText((String) task.getResult().get("color"));
            petWeight.setText((String) task.getResult().get("weight"));


            loadImages((String) task.getResult().get("type"));

            //petLocation.setText((String) task.getResult().get("location"));

            call.setOnClickListener(v -> {
                db.collection("users").document((String) task.getResult().get("uid")).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        Intent callIntent = new Intent(Intent.ACTION_DIAL);
                        callIntent.setData(Uri.parse("tel:" + task.getResult().get("phone")));
                        startActivity(callIntent);
                    }
                });
            });
        });
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        LatLng sydney = new LatLng(12, 12);
        googleMap.addMarker(new MarkerOptions()
                .position(sydney)
                .title("Pet Location"));
        googleMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));
        googleMap.animateCamera(CameraUpdateFactory.zoomIn());
        googleMap.animateCamera(CameraUpdateFactory.zoomTo(10), 2000, null);
    }
}