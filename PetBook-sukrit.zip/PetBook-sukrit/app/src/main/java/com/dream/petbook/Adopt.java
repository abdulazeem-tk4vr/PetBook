package com.dream.petbook;

import java.util.ArrayList;

public class Adopt {
    private String age;
    private String name;
    private String breed;
    private String species;
    private String height;
    private String weight;
    private String color;
    private String pin;
    private ArrayList<String> url;
    private String gender;
    private String desc;
    private String uid;
    private String type;
    private String boost;
    public Adopt()
    {

    }
    public Adopt(String age, String height, String weight, String name, String breed,
                 String species, String color, String pin, ArrayList<String>url, String gender, String desc, String uid, String boost, String type)
    {
        this.age=age;
        this.name=name;
        this.breed=breed;
        this.species=species;
        this.height=height;
        this.weight=weight;
        this.color=color;
        this.pin=pin;
        this.url=url;
        this.gender=gender;
        this.desc=desc;
        this.uid=uid;
        this.type=type;
        this.boost=boost;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }


    public String getBreed() {
        return breed;
    }

    public String getName() {
        return name;
    }

    public ArrayList<String> getUrl() {
        return url;
    }

    public void setUrl(ArrayList<String> url) {
        this.url = url;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getBoost() {
        return boost;
    }

    public void setBoost(String boost) {
        this.boost = boost;
    }

    public void setBreed(String breed) {
        this.breed = breed;
    }

    public String getColor() {
        return color;
    }

    public String getPin() {
        return pin;
    }

    public String getSpecies() {
        return species;
    }

    public void setColor(String color) {
        this.color = color;
    }




    public void setName(String name) {
        this.name = name;
    }

    public void setSpecies(String species) {
        this.species = species;
    }

    public void setPin(String pin) {
        this.pin = pin;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public void setHeight(String height) {
        this.height = height;
    }

    public String getAge() {
        return age;
    }

    public String getHeight() {
        return height;
    }

    public String getWeight() {
        return weight;
    }

}
