package com.dream.petbook;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.firestore.FirebaseFirestore;

public class LoginActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private RelativeLayout relativeLayout;
    private SignInButton signInButton;
    FirebaseFirestore db = FirebaseFirestore.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        relativeLayout = findViewById(R.id.main_layout);
        signInButton = findViewById(R.id.sign_in_button);
        signInButton.setSize(SignInButton.SIZE_WIDE);
        mAuth = FirebaseAuth.getInstance();

        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.web_client_id))
                .requestEmail()
                .build();

        GoogleSignInClient mGoogleSignInClient = GoogleSignIn.getClient(this, gso);

        if (mAuth.getCurrentUser() == null) {
            Intent signInIntent = mGoogleSignInClient.getSignInIntent();
            ActivityResultLauncher<Intent> activityResultLauncher = registerForActivityResult(
                    new ActivityResultContracts.StartActivityForResult(),
                    result -> {
                        if(result.getResultCode() == Activity.RESULT_OK) {
                            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(result.getData());
                            handleSignInResult(task);
                        }
                    });
            signInButton.setOnClickListener(v -> {
                activityResultLauncher.launch(signInIntent);
            });
        } else {
            checkDetailsFilled(mAuth.getCurrentUser().getUid());
        }
    }

    private void handleSignInResult(Task<GoogleSignInAccount> task) {
        try {
            GoogleSignInAccount googleSignInAccount = task.getResult(ApiException.class);
            firebaseAuthWithGoogle(googleSignInAccount.getIdToken());
        } catch (ApiException e) {
            Snackbar.make(relativeLayout, "Error in GCP authentication", Snackbar.LENGTH_LONG).show();
        }
    }

    private void checkDetailsFilled(String uid) {
        db.collection("users").document(uid).get().addOnCompleteListener(task -> {
            if(task.isSuccessful()) {
                if(task.getResult().exists()) {
                    startActivity(new Intent(LoginActivity.this, DashboardActivity.class));
                    finish();
                } else {
                    startActivity(new Intent(LoginActivity.this, SignUp.class));
                }
            }
        }).addOnFailureListener(e -> {
        });
    }

    private void firebaseAuthWithGoogle(String idToken) {
        AuthCredential credential = GoogleAuthProvider.getCredential(idToken, null);
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        if(mAuth.getCurrentUser() != null) {
                            Toast.makeText(LoginActivity.this, "Logged in as " + mAuth.getCurrentUser().getEmail(), Toast.LENGTH_SHORT).show();
                            checkDetailsFilled(mAuth.getCurrentUser().getUid());
                        }
                    } else {
                        Snackbar.make(relativeLayout, "Error in authentication", Snackbar.LENGTH_SHORT).show();
                    }
                });
    }
}