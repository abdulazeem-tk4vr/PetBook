package com.dream.petbook;

import android.content.ClipData;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageSwitcher;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewSwitcher;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.ArrayList;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class AddAdopt extends AppCompatActivity {

    Button select, previous, next;
    ImageSwitcher imageView;
    EditText name, species, breed, age, height, weight, color, desc, pincode;
    Button done;
    int PICK_IMAGE_MULTIPLE = 1;
    String imageEncoded;
    private StorageReference storageRef;
    FirebaseFirestore db;
    CircleImageView pic;
    ArrayList<Uri> mArrayUri;
    private Validation valid;
    int position = 0;
    String gender = "n";
    String boost = "n";
    List<String> imagesEncodedList;
    TextView heading;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_adopt);
        select = findViewById(R.id.select);
        imageView = findViewById(R.id.image);
        previous = findViewById(R.id.previous);
        name = findViewById(R.id.name);
        species = findViewById(R.id.species);
        breed = findViewById(R.id.breed);
        age = findViewById(R.id.age);
        height = findViewById(R.id.height);
        weight = findViewById(R.id.weight);
        color = findViewById(R.id.color);
        desc = findViewById(R.id.desc);
        done = findViewById(R.id.done);
        pincode = findViewById(R.id.pincode);
        heading = findViewById(R.id.heading);
        mArrayUri = new ArrayList<Uri>();
        pic = findViewById(R.id.profile1);
        valid = new Validation(AddAdopt.this);
        String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();

        heading.setText("ADD " + getIntent().getStringExtra("type").toUpperCase() + " POST");

        storageRef = FirebaseStorage.getInstance().getReference("profile/" + uid);
        Task<Uri> uri = storageRef.getDownloadUrl().addOnCompleteListener(new OnCompleteListener<Uri>() {
            @Override
            public void onComplete(@NonNull Task<Uri> task) {
                Uri ur = task.getResult();
                Glide.with(getApplicationContext()).load(ur).into(pic);
            }
        });
        // showing all images in imageswitcher
        imageView.setFactory(new ViewSwitcher.ViewFactory() {
            @Override
            public View makeView() {
                ImageView imageView1 = new ImageView(getApplicationContext());
                return imageView1;
            }
        });
        next = findViewById(R.id.next);
        // click here to select next image
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (position < mArrayUri.size() - 1) {
                    // increase the position by 1
                    position++;
                    imageView.setImageURI(mArrayUri.get(position));
                } else {
                    Toast.makeText(AddAdopt.this, "Last Image Already Shown", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // click here to view previous image
        previous.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (position > 0) {
                    // decrease the position by 1
                    position--;
                    imageView.setImageURI(mArrayUri.get(position));
                }
            }
        });

        imageView = findViewById(R.id.image);
        // click here to select image
        select.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // initialising intent
                Intent intent = new Intent();

                // setting type to select to be image
                intent.setType("image/*");

                // allowing multiple image to be selected
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_MULTIPLE);
            }
        });
        done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mArrayUri.isEmpty()) {
                    Toast.makeText(getApplicationContext(), "You haven't picked Image", Toast.LENGTH_LONG).show();
                } else {
                    if (!valid.isEditTextFilled(name, "Enter name") || !valid.isEditTextFilled(breed, "Enter Breed") ||
                            !valid.isEditTextFilled(species, "Enter species") || !valid.isEditTextFilled(height, "Enter height") ||
                            !valid.isEditTextFilled(weight, "Enter weight") || !valid.isEditTextFilled(color, "Enter color") || !valid.isEditTextFilled(pincode, "Enter Pincode") || !valid.isEditTextFilled(age, "Enter age"))
                        return;
                    else {
                        ArrayList<String> uri = new ArrayList<>();
                        db = FirebaseFirestore.getInstance();
                        for (int i = 0; i < mArrayUri.size(); i++)
                            uri.add(mArrayUri.get(i).toString());
                        Adopt a = new Adopt(age.getText().toString().trim(), height.getText().toString().trim()
                                , weight.getText().toString().trim(), name.getText().toString().trim(),
                                breed.getText().toString().trim(), species.getText().toString(), color.getText().toString(),
                                pincode.getText().toString().trim(), uri, gender, desc.getText().toString().trim(), uid, boost, getIntent().getStringExtra("type").toLowerCase());
                        Task<DocumentReference> ds=db.collection("posts").add(a).addOnCompleteListener(new OnCompleteListener<DocumentReference>() {
                            @Override
                            public void onComplete(@NonNull Task<DocumentReference> task) {
                                String did=task.getResult().getId();
                                for (int i=0;i<mArrayUri.size();i++)
                                {
                                    storageRef = FirebaseStorage.getInstance().getReference("posts/" + getIntent().getStringExtra("type").toLowerCase() + did+i);
                                    storageRef.putFile(mArrayUri.get(i)).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                                        @Override
                                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                            System.out.println("pics added");
                                        }
                                    });
                                }
                                startActivity(new Intent(getApplicationContext(),DashboardActivity.class));
                            }
                        });
                        System.out.println("added");
                    }
                }
            }
        });
    }

    public void onRadioButtonClicked(View view) {
        // Is the button now checked?
        boolean checked = ((RadioButton) view).isChecked();

        // Check which radio button was clicked
        switch (view.getId()) {
            case R.id.male:
                if (checked)
                    gender = "m";
                break;
            case R.id.female:
                if (checked)
                    gender = "f";
                break;
            case R.id.neutered:
                if (checked)
                    gender = "n";
                break;
            default:
                gender = "n";
                break;
        }
    }

    public void onRadioButtonClicked1(View view) {
        // Is the button now checked?
        boolean checked = ((RadioButton) view).isChecked();

        // Check which radio button was clicked
        switch (view.getId()) {
            case R.id.yes:
                if (checked)
                    boost = "y";
                break;
            case R.id.no:
                if (checked)
                    boost = "n";
                break;
            default:
                boost = "n";
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // When an Image is picked
        if (requestCode == PICK_IMAGE_MULTIPLE && resultCode == RESULT_OK && null != data) {
            // Get the Image from data
            if (data.getClipData() != null) {
                ClipData mClipData = data.getClipData();
                int cout = data.getClipData().getItemCount();
                for (int i = 0; i < cout; i++) {
                    // adding imageuri in array
                    Uri imageurl = data.getClipData().getItemAt(i).getUri();
                    mArrayUri.add(imageurl);
                }
                // setting 1st selected image into image switcher
                imageView.setImageURI(mArrayUri.get(0));
                position = 0;
            } else {
                Uri imageurl = data.getData();
                mArrayUri.add(imageurl);
                imageView.setImageURI(mArrayUri.get(0));
                position = 0;
            }
        } else {
            // show this if no image is selected
            Toast.makeText(this, "You haven't picked Image", Toast.LENGTH_LONG).show();
        }
    }
}
