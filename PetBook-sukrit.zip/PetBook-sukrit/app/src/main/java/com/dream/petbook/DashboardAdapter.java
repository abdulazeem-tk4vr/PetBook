package com.dream.petbook;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

public class DashboardAdapter extends BaseAdapter {
    private final String name[];
    private final int images[];
    Context context;

    public DashboardAdapter(Context context, String[] name, int[] images) {
        this.context = context;
        this.name = name;
        this.images = images;
    }

    @Override
    public int getCount() {
        return name.length;
    }

    @Override
    public Object getItem(int position) {
        return 0;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = layoutInflater.inflate(R.layout.singleframe, null);

        ImageView img = (ImageView) view.findViewById(R.id.iconimage);
        TextView tv = (TextView) view.findViewById(R.id.textdata);

        img.setImageResource(images[position]);
        tv.setText(name[position]);

        view.setOnClickListener(v -> {
            DashboardActivity dashboardActivity = (DashboardActivity) context;
            FragmentManager fragmentManager = dashboardActivity.getSupportFragmentManager();

            Fragment fragment;

            try {
                fragment = (Fragment) BuyListFragment.class.newInstance();
                dashboardActivity.selected = name[position].toLowerCase();

                switch(name[position].toLowerCase()) {
                    case "adopt":
                        dashboardActivity.dimTextColors(dashboardActivity.adopt);
                        break;
                    case "found":
                        dashboardActivity.dimTextColors(dashboardActivity.found);
                        break;
                    case "lost":
                        dashboardActivity.dimTextColors(dashboardActivity.lost);
                        break;
                    case "buy":
                        dashboardActivity.dimTextColors(dashboardActivity.buy);
                        break;
                    case "petcare":
                        dashboardActivity.dimTextColors(dashboardActivity.petcare);
                        fragment = PetCare.class.newInstance();
                        break;
                    case "guide":
                        dashboardActivity.dimTextColors(dashboardActivity.guide);
                        fragment = Guide.class.newInstance();
                        break;
                }

                fragmentManager.beginTransaction().setCustomAnimations(android.R.animator.fade_in, android.R.animator.fade_out).replace(R.id.frameLayout, fragment).commit();
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

        return view;
    }
}
