package com.dream.petbook;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import de.hdodenhof.circleimageview.CircleImageView;

public class DashboardActivity extends AppCompatActivity {

    FrameLayout frameLayout;
    CircleImageView pic;
    public TextView name, home, adopt, found, lost, buy, petcare, guide, profile, logout;
    public static Fragment fragment;
    private StorageReference storageRef;
    FirebaseFirestore db;
    public String selected;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        frameLayout = findViewById(R.id.frameLayout);
        pic = findViewById(R.id.pic);
        name = findViewById(R.id.name);
        home = findViewById(R.id.home);
        adopt = findViewById(R.id.adopt);
        found = findViewById(R.id.found);
        lost = findViewById(R.id.lost);
        buy = findViewById(R.id.buy);
        petcare = findViewById(R.id.petcare);
        guide = findViewById(R.id.guide);
        profile = findViewById(R.id.profile);
        logout = findViewById(R.id.logout);

        String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();

        storageRef = FirebaseStorage.getInstance().getReference("profile/"+uid);
        Task<Uri> uri= storageRef.getDownloadUrl().addOnCompleteListener(new OnCompleteListener<Uri>() {
            @Override
            public void onComplete(@NonNull Task<Uri> task) {
                if(task.isSuccessful()) {
                    Uri ur=task.getResult();
                    Glide.with(DashboardActivity.this).load(ur).into(pic);
                }
            }
        });
        db= FirebaseFirestore.getInstance();
        DocumentReference docRef = db.collection("users").document(uid);
        docRef.get().addOnSuccessListener(documentSnapshot -> {
            User user = documentSnapshot.toObject(User.class);
            name.setText(user.getName());
        });

        try {
            fragment = DashboardFragment.class.newInstance();
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (fragment != null) {
            FragmentManager fragmentManager = getSupportFragmentManager();
            fragmentManager.beginTransaction().setCustomAnimations(android.R.animator.fade_in, android.R.animator.fade_out).replace(R.id.frameLayout, fragment).commit();
        }
        home.setTextColor(Color.WHITE);

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loadFragment(DashboardFragment.class);
                dimTextColors(home);
            }
        });

        adopt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loadFragment(BuyListFragment.class);
                dimTextColors(adopt);
                selected = "adopt";
            }
        });

        found.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loadFragment(BuyListFragment.class);
                dimTextColors(found);
                selected = "found";
            }
        });

        lost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loadFragment(BuyListFragment.class);
                dimTextColors(lost);
                selected = "lost";
            }
        });

        buy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loadFragment(BuyListFragment.class);
                dimTextColors(buy);
                selected = "buy";
            }
        });

        petcare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loadFragment(PetCare.class);
                dimTextColors(petcare);
            }
        });

        guide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loadFragment(Guide.class);
                dimTextColors(guide);
            }
        });

        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loadFragment(ProfileFragment.class);
                dimTextColors(profile);
            }
        });

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseAuth.getInstance().signOut();
                GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                        .requestIdToken(getString(R.string.web_client_id))
                        .requestEmail()
                        .build();

                GoogleSignInClient mGoogleSignInClient = GoogleSignIn.getClient(DashboardActivity.this, gso);
                mGoogleSignInClient.signOut().addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        startActivity(new Intent(DashboardActivity.this, LoginActivity.class));
                    }
                });
            }
        });

    }

    public void loadFragment(Class fragmentClass) {
        try {
            fragment = (Fragment) fragmentClass.newInstance();
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (fragment != null) {
            FragmentManager fragmentManager = getSupportFragmentManager();
            fragmentManager.beginTransaction().setCustomAnimations(android.R.animator.fade_in, android.R.animator.fade_out).replace(R.id.frameLayout, fragment).commit();
            maximiseFrameLayout();
        }
    }

    public void minimiseFrameLayout() {
        Animation animation = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
        frameLayout.startAnimation(animation);
        frameLayout.setTranslationZ(0);
    }

    public void maximiseFrameLayout() {
        Animation animation = AnimationUtils.loadAnimation(this, R.anim.zoom_in);
        frameLayout.startAnimation(animation);
        frameLayout.setTranslationZ(100);
    }

    public void dimTextColors(TextView whiteTextView) {
        home.setTextColor(Color.parseColor("#B1B1B1"));
        adopt.setTextColor(Color.parseColor("#B1B1B1"));
        found.setTextColor(Color.parseColor("#B1B1B1"));
        lost.setTextColor(Color.parseColor("#B1B1B1"));
        buy.setTextColor(Color.parseColor("#B1B1B1"));
        petcare.setTextColor(Color.parseColor("#B1B1B1"));
        guide.setTextColor(Color.parseColor("#B1B1B1"));

        whiteTextView.setTextColor(Color.WHITE);
    }
    public void lab()
    {
        Intent intent = new Intent(getApplicationContext(),GuideBreed.class);
        intent.putExtra("t","lab");
        startActivity(intent);
    }
    public void germ()
    {
        Intent intent = new Intent(getApplicationContext(),GuideBreed.class);
        intent.putExtra("t","germ");
        startActivity(intent);
    }
    public void guidedog()
    {
        loadFragment(Guide_breed.class);
    }

    public void addAdopt()
    {
        Intent intent = new Intent(getApplicationContext(),AddAdopt.class);
        intent.putExtra("type", "Adopt");
        startActivity(intent);
    }
    public void addFound()
    {
        Intent intent = new Intent(getApplicationContext(),AddAdopt.class);
        intent.putExtra("type", "Found");
        startActivity(intent);
    }
    public void addLost()
    {
        Intent intent = new Intent(getApplicationContext(),AddAdopt.class);
        intent.putExtra("type", "Lost");
        startActivity(intent);
    }
    public void addBuy()
    {
        Intent intent = new Intent(getApplicationContext(),AddAdopt.class);
        intent.putExtra("type", "Buy");
        startActivity(intent);
    }
}